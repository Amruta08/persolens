from app.core.m import slow_add
result = slow_add.delay(2, 3)
print(result.id)
print(result.status)