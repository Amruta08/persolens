from celery import Celery
import time

celery_app = Celery("demo", broker="redis://localhost:6379/0", backend="redis://localhost:6379/0")

@celery_app.task
def slow_add(x, y):
    time.sleep(5)
    return x + y